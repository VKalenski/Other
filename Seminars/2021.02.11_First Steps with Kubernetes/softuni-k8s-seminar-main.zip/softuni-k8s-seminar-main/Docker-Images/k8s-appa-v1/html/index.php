<html lang="en">
  <head>
    <meta content="text/html; charset=UTF-8" http-equiv="content-type">
    <title>World of Kubernetes</title>
  </head>
  <body>
    <div align="center">
      <img width="400px" height="400px" src="kubernetes-logo.png">
      <h1>Welcome to the world of <span style="color: blue;">Kubernetes</span>!</h1>
      <h2>There is plenty to explore here ...</h2>
      <h2>You can start with the name: <span style="color: blue;">κυβερνήτης</span> &rArr; <span style="color: blue;">kubernetes</span> &rArr; <span style="color: blue;">k8s</span> :)</h2>
      <br /><br /><br />
      Running on <b><?php echo gethostname(); ?></b>
    </div>
  </body>
</html> 
