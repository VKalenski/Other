﻿using System;
using System.Collections.Generic;

namespace FishingNet
{
    public class Net
    {
        new List<Fish> fishList;

        public Net(string material, int capacity)
        {
            Material = material;
            Capacity = capacity;
            fishList = new List<Fish>();
        }
        public string Material { get; set; }
        public int Capacity { get; set; }

        public int Count 
        { 
            get
            {
                return fishList.Count;
            }
        }

        public string AddFish(Fish fish)
        {
            if (fish == null || fish.Length <= 0 || fish.Weight <= 0)
            {
                return $"Invalid fish.";
            }
            else if (fishList.Count >= Capacity)
            {
                return "Fishing net is full.";
            }            

            fishList.Add(fish);

            return $"Successfully added {fish} to the fishing net.";
        }

        public bool ReleaseFish(double weight)
        {
            return true;
        }
    }
}